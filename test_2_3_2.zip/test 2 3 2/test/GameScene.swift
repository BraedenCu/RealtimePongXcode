//
//  GameScene.swift
//  test
//
//  Created by Braeden Cullen on 3/16/20.
//  Copyright © 2020 Braeden Cullen. All rights reserved.
//
import SpriteKit
import GameplayKit
import MultipeerConnectivity

class GameScene: SKScene, SKPhysicsContactDelegate {
    var ball = SKShapeNode()
    var paddle = SKSpriteNode()
    var paddle2 = SKSpriteNode()
    var bricks = [SKSpriteNode]()
    var playLabel = SKLabelNode()
    var personalScore = SKLabelNode()
    var otherPersonScore = SKLabelNode()
    var personalSco = 0
    var otherPersonSco = 0
    var playingGame = false
    var ready = false
    var otherReady = false
    var connected = false
    var personPlaying = false
    
    var paddleColor = UIColor.white
    var ballColor = UIColor.orange
    
    let protocolNumber = Int.random(in: -500000000...500000000) 
    var network = networkManager() // Create a networkmanager for this user
    var hasNetworkPriority = false
    
    override func didMove(to view: SKView) {
        // this stuff happens once (when app opens)
        physicsWorld.contactDelegate = self
        self.physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        createBackground()
        makeLoseZone()
        makeLabels()
        resetGame()
        
        let queue = DispatchQueue(label: "gameLoop")
        queue.async {
            while true {
                usleep(50000)
                if(self.connected) {
                    self.playLabel.text = "Tap to play!"
                } else {
                    
                    self.playLabel.text = "Connecting..."
                }
                if(self.hasNetworkPriority) {
                    if(self.playingGame && self.ball.physicsBody!.velocity.dx == 0 && self.ball.physicsBody! .velocity.dy == 0) {
                        self.kickBall()
                    }
                    self.sendBallPosition()

                }
                self.network.send(value: "myPaddle:" + String(Float(self.paddle.position.x)))
            }
        }
        
        network.delegate = self
        network.startLooking()
    }
    
    func resetGame() {
        // this stuff happens before each game starts
        playLabel.alpha = 1
        ball.removeFromParent()
        makeBall()
        paddle.removeFromParent()
        paddle2.removeFromParent()
        ready = false
        otherReady = false
        makePaddle()
        updateLabels()
        
    }
    func kickBall() {
        ball.physicsBody?.isDynamic = true
        ball.physicsBody?.applyImpulse(CGVector(dx: 5, dy: -5))
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            if(playingGame) {
                self.network.send(value: "implaying")
                paddle.position.x = location.x
                network.send(value: "myPaddle:" + String(Float(location.x)))
            }
            else {
                for node in nodes(at: location) {
                    if node.name == "play" {
                        if(connected) {
                            network.send(value: "Ready")
                            ready = true
                            testReady()
                            playingGame = true
                            node.alpha = 0
                        }

                    }
                }
            }
        }
    }
    
    func beginGame() {
        updateLabels()
        print("Start!")
        if(hasNetworkPriority) {
            kickBall()
        }
        if personPlaying == true {
            kickBall()
        }
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            if(playingGame) {
                paddle.position.x = location.x
                network.send(value: "myPaddle:" + String(Float(location.x)))
            }
        }
    }
    func didBegin(_ contact: SKPhysicsContact) {
        
        if contact.bodyB.node?.name == "loseZone" || contact.bodyA.node?.name == "loseZone" {
            self.score(mine: false)
            self.network.send(value: "losehit")
            pointOver()
        }

    }
    
    func score(mine: Bool) {
        if (mine) {
            personalSco += 1
        } else {
            otherPersonSco += 1
        }
    }
    
    func createBackground() {
  
        let rick = SKTexture(imageNamed: "background")

        let rollBackground = SKSpriteNode(texture: rick)
        rollBackground.zPosition = -1
        rollBackground.position = CGPoint(x: frame.midX, y: frame.midY)
        addChild(rollBackground)
 
    }
    
    func makeBall() {
        ball = SKShapeNode(circleOfRadius: 10)
        ball.position = CGPoint(x: frame.midX, y: frame.midY)
        ball.strokeColor = UIColor.black
        ball.fillColor = ballColor
        ball.name = "ball"
        // physics shape matches ball image
        ball.physicsBody = SKPhysicsBody(circleOfRadius: 10)
        // ignores all forces and impulses
        ball.physicsBody?.isDynamic = false
        // use precise collision detection
        ball.physicsBody?.usesPreciseCollisionDetection = true
        // no loss of energy from friction
        ball.physicsBody?.friction = 0
        // gravity is not a factor
        ball.physicsBody?.affectedByGravity = false
        // bounces fully off of other objects
        ball.physicsBody?.restitution = 1
        // does not slow down over time
        ball.physicsBody?.linearDamping = 0
        ball.physicsBody?.contactTestBitMask =
            (ball.physicsBody?.collisionBitMask)!
        addChild(ball) // add ball object to the view
    }
    func makePaddle() {
        paddle = SKSpriteNode(color: UIColor.white, size: CGSize(width: frame.width / 6, height: 20))
        paddle2 = SKSpriteNode(color: UIColor.white, size: CGSize(width: frame.width / 6, height: 20))
        paddle.position = CGPoint(x: frame.midX, y: frame.minY + 125)
        paddle2.position = CGPoint(x: frame.midX, y: frame.maxY - 125)
        
        paddle.color = paddleColor
        paddle2.color = paddleColor
        
        paddle.name = "paddle"
        paddle2.name = "paddle2"
        paddle.physicsBody = SKPhysicsBody(rectangleOf:
            paddle.size)
        paddle.physicsBody?.isDynamic = false
        addChild(paddle)
        paddle2.physicsBody = SKPhysicsBody(rectangleOf:
            paddle2.size)
        paddle2.physicsBody?.isDynamic = false
        addChild(paddle2)
    }

    func makeLoseZone() {
        let loseZone = SKSpriteNode(color: UIColor.red, size: CGSize(width:
            frame.width, height: 50))
        loseZone.position = CGPoint(x: frame.midX, y: frame.minY + 25)
        loseZone.name = "loseZone"
        loseZone.physicsBody = SKPhysicsBody(rectangleOf: loseZone.size)
        loseZone.physicsBody?.isDynamic = false
        addChild(loseZone)
    }
    
    func sendBallPosition() {
        if(hasNetworkPriority) {
            network.send(value: "ballx:" + String(Float(ball.position.x)))
            network.send(value: "bally:" + String(Float(ball.position.y)))
            //print("sentBallPos")
        }
    }
    
    
    func makeLabels() {
        playLabel.fontSize = 36
        playLabel.text = "Click to play"
        playLabel.position = CGPoint(x: frame.midX, y: frame.midY - 50)
        playLabel.name = "play"
        addChild(playLabel)
        otherPersonScore.fontSize = 36
        otherPersonScore.fontColor = UIColor.white
        otherPersonScore.fontName = "Arial"
        otherPersonScore.position = CGPoint(x: frame.minX + 150, y: frame.minY + 100)
        addChild(otherPersonScore)
        personalScore.fontSize = 36
        personalScore.fontColor = UIColor.white
        personalScore.fontName = "Arial"
        personalScore.position = CGPoint(x: frame.minX - 150, y: frame.maxY - 50)
        addChild(personalScore)
    }
    func pointOver() {
        playingGame = false
        playLabel.text = "Ready"
        playLabel.alpha = 1
        resetGame()
    }
    func updateLabels() {
        otherPersonScore.text = "Score: \(personalSco)"
        personalScore.text = "Lives: \(otherPersonSco)"
    }
    
    func testReady() {
        print(ready)
        print(otherReady)
        if(ready && otherReady) {
            beginGame()
        }
    }
}

extension GameScene : networkManagerDelegate {

    
     func connectedDevicesDidChange(superclass: networkManager, connectedDevices: [String]) {
         OperationQueue.main.addOperation {
            
             if connectedDevices.count == 1 {
                self.network.stopLooking()
                //self.beginNetworkGame()
                self.network.send(value: "Prot:" + String(self.protocolNumber))
                self.connected = true
             } else if connectedDevices.count == 0 {
                print("You have stopped receiving data from the other player.")
                self.connected = false
                self.pointOver()
            }

         }
     }
    
    func didDiscoverUser(superclass:
        networkManager, data: MCPeerID) {
        print("\n\nDISCOVERY\n\n")
    }
    
    func valueDidChange(superclass: networkManager, data: Data) {
        let str = String(data: data, encoding: .utf8)!
        OperationQueue.main.addOperation {
            
            
            if str.contains("Prot:") { // Determine first player by protocol
                print(str.dropFirst(5))
                print(String(self.protocolNumber) + " ?>? " + (String(str.dropFirst(9))) + "\n is: " + String(self.protocolNumber >  Int(String(str.dropFirst(5)))!))
                if self.protocolNumber >  Int(String(str.dropFirst(5)))! {
                    self.hasNetworkPriority = true
                }
            
            }
            
            if str == "DC" { // Force disconnect
                print("The other player has disconnected.")
                self.ready = false
                self.otherReady = false
            }
            
            if self.playingGame == false { // If we are waiting...
                if str.contains("Ready") {
                    self.otherReady = true
                    self.testReady()
                }
            } else { // We recieve data from the person who doesn't have network priority
                if str.contains("ballx:") {
                    let val = str.dropFirst(6)
                    
                    self.ball.position = CGPoint(x: self.frame.midX - CGFloat(Float(val)!), y: self.ball.position.y)
                }
                
                if str.contains("bally:") {
                    let val = str.dropFirst(6)
                    
                    self.ball.position = CGPoint(x: self.ball.position.x, y: self.frame.midY - CGFloat(Float(val)!))
                    
                    if(!self.hasNetworkPriority) {
                        if(self.ball.position.y < self.paddle.position.y - CGFloat(10.0)) {
                            self.network.send(value: "losehit")
                            self.pointOver()
                        }
                    }
                }
                
                if str.contains("myPaddle:") {
                    let val = str.dropFirst(9)
                    
                    self.paddle2.position = CGPoint(x: self.frame.midX - CGFloat(Float(val)!), y: self.frame.maxY - 125)
                    
                    
                }
                
                if str.contains("losehit") {
                    self.score(mine: true)
                    self.pointOver()
                    if(self.hasNetworkPriority) {
                        self.ball.position = CGPoint(x: self.frame.midX, y: self.frame.midY)
                    }
                }
                if str.contains("implaying") {
                    self.personPlaying = true
                    
                }

            }

        }
        
    }
}
