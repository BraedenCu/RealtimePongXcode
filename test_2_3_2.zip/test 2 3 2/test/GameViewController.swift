//
//  GameViewController.swift
//  test
//
//  Created by Braeden Cullen on 3/16/20.
//  Copyright © 2020 Braeden Cullen. All rights reserved.
//

import UIKit
import SpriteKit
import GameplayKit

class GameViewController: UIViewController {

    var paddleColor = UIColor.white
    var ballColor = UIColor.orange
    
    @IBOutlet var background: SKView!
    @IBOutlet weak var bigBoyView: UIView!
    @IBOutlet weak var buttonView: UIView!
        
    override func viewDidLoad() {
        
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        bigBoyView.isHidden = true
        
            if let view = self.view as! SKView? {

                let scene = SKScene(fileNamed: "GameScene")

                scene?.scaleMode = .aspectFill
                  
                let game = scene as? GameScene
                
                game?.paddleColor = paddleColor
                game?.ballColor = ballColor
                  view.presentScene(scene)
              
        }
    }
}


