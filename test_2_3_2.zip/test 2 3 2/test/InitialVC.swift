//
//  InitialVC.swift
//  test
//
//  Created by Braeden Cullen on 5/14/20.
//  Copyright © 2020 Braeden Cullen. All rights reserved.
//

import UIKit

class InitialVC: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var paddleColor = UIColor.white
    @IBOutlet weak var colorSelectLabel: UILabel!
    var ballColor = UIColor.orange
 
    


    @IBOutlet weak var colorSelection: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        colorSelection.delegate = self
        colorSelection.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.destination is GameViewController
        {
            let vc = segue.destination as? GameViewController
            vc?.paddleColor = paddleColor
            vc?.ballColor = ballColor
        }
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         return 3
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell = colorSelection.dequeueReusableCell(withIdentifier: "defaultColorCell", for: indexPath)
         if(indexPath.row == 1) {
             cell = colorSelection.dequeueReusableCell(withIdentifier: "defaultColorCell", for: indexPath)
         } else if (indexPath.row == 2) {
             cell = colorSelection.dequeueReusableCell(withIdentifier: "invertedColorCell", for: indexPath)
         } else {
             cell = colorSelection.dequeueReusableCell(withIdentifier: "BlueWorldColorCell", for: indexPath)
         }
        return cell
     }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if (indexPath.row == 1) {
            paddleColor = .white
            ballColor = .orange
            colorSelectLabel.text = "Selected Scheme: Default"
        } else if (indexPath.row == 2) {
            paddleColor = .orange
            ballColor = .white
            colorSelectLabel.text = "Selected Scheme: Inverted"
        } else {
            paddleColor = .blue
            ballColor = .blue
            colorSelectLabel.text = "Selected Scheme: Blue"
        }
    }

}
