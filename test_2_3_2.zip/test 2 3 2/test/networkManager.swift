//
//  networkManager.swift
//  test
//
//  Created by Michael Karpov on 5/11/20.
//  Copyright © 2020 Braeden Cullen. All rights reserved.
//


import Foundation
import MultipeerConnectivity

protocol networkManagerDelegate {
    func connectedDevicesDidChange(superclass: networkManager, connectedDevices: [String])
    func valueDidChange(superclass: networkManager, data: Data)
    func didDiscoverUser(superclass: networkManager, data: MCPeerID)
}

class networkManager : NSObject {
    // Initiate class values
    private let Service = "coronaPong"
    private let myID = MCPeerID(displayName: UIDevice.current.name)
    private let MCserviceAdvertiser : MCNearbyServiceAdvertiser
    private let MCserviceBrowser : MCNearbyServiceBrowser
    
    
    //Set method delegate
    var delegate : networkManagerDelegate?
    
    //Create our session so we can actually connect to others
    lazy var session : MCSession = {
        let session = MCSession(peer: self.myID, securityIdentity: nil, encryptionPreference: .required)
        session.delegate = self
        return session
    }()

    
    // When class must be initiated
    override init() {
        self.MCserviceAdvertiser = MCNearbyServiceAdvertiser(peer: myID, discoveryInfo: nil, serviceType: Service)
        self.MCserviceBrowser = MCNearbyServiceBrowser(peer: myID, serviceType: Service)
        super.init()
        self.MCserviceBrowser.delegate = self
        self.MCserviceAdvertiser.delegate = self
    }
    
    //start looking for players
    func startLooking() {
        self.MCserviceAdvertiser.startAdvertisingPeer()
        self.MCserviceBrowser.startBrowsingForPeers()
    }

    // stop looking for players
    func stopLooking() {
        self.MCserviceAdvertiser.stopAdvertisingPeer()
        self.MCserviceBrowser.stopBrowsingForPeers()
    }

    // helper function to send data through
    func send(value : String) {
        //print("sendValueDict to \(session.connectedPeers.count) peers : \(value) ")
        if session.connectedPeers.count > 0 {
            do {
                try self.session.send(value.data(using: .utf8)!, toPeers: session.connectedPeers, with: .reliable)
            }
            catch let error {
                print("Error: \(error)")
            }
        }
    }

}

extension networkManager : MCNearbyServiceAdvertiserDelegate {

    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didNotStartAdvertisingPeer error: Error) {
        print(error)
    }

    func advertiser(_ advertiser: MCNearbyServiceAdvertiser, didReceiveInvitationFromPeer peerID: MCPeerID, withContext context: Data?, invitationHandler: @escaping (Bool, MCSession?) -> Void) {
        print("Connecting to \(peerID.displayName)")
        invitationHandler(true, self.session)
    }

}

extension networkManager : MCNearbyServiceBrowserDelegate {

    func browser(_ browser: MCNearbyServiceBrowser, didNotStartBrowsingForPeers error: Error) {
        print(error)
    }

    func browser(_ browser: MCNearbyServiceBrowser, foundPeer peerID: MCPeerID, withDiscoveryInfo info: [String : String]?) {
        
    self.delegate?.didDiscoverUser(superclass: self, data: peerID)

        print("foundPeer: \(peerID)")
        print("inviting peer : \(peerID.displayName)")
        browser.invitePeer(peerID, to: self.session, withContext: nil, timeout: 10)
    }

    func browser(_ browser: MCNearbyServiceBrowser, lostPeer peerID: MCPeerID) {
        print("lostPeer: \(peerID)")
    }

}

extension networkManager : MCSessionDelegate {
    
    func session(_ session: MCSession, peer peerID: MCPeerID, didChange state: MCSessionState) {
         print("peer \(peerID) didChangeState: \(state.rawValue)")

         self.delegate?.connectedDevicesDidChange(superclass: self, connectedDevices:session.connectedPeers.map{$0.displayName}) }

    func session(_ session: MCSession, didReceive data: Data, fromPeer peerID: MCPeerID) {
        
        self.delegate?.valueDidChange(superclass: self, data: data)
    }

    func session(_ session: MCSession, didReceive stream: InputStream, withName streamName: String, fromPeer peerID: MCPeerID) {
        print("Recieved unwanted data stream")
    }

    func session(_ session: MCSession, didStartReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, with progress: Progress) {
        print("Recieved unwanted resource")
    }

    func session(_ session: MCSession, didFinishReceivingResourceWithName resourceName: String, fromPeer peerID: MCPeerID, at localURL: URL?, withError error: Error?) {
        print("Recieved unwanted resource")
    }

}
